
void main() throws IOException {
    Game game = new Game();
    game.start();
    if (game.isGameWon()) {
        IO.println("Congratulations! You've won the game!");
    } else {
        IO.println("Game over! Better luck next time!");
    }

}

